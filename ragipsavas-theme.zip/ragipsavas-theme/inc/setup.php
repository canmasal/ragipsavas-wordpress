<?php
/**
 * Kurulum: tema etkinleştirildiğinde sayfa ve menüyü otomatik oluşturur (yalnızca bir kez)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_switch_theme', 'ragip_first_setup', 20 );
function ragip_first_setup() {
	if ( get_option( 'ragip_setup_done' ) ) {
		return;
	}

	// 1. Başvuru Formu sayfası (slug: basvuru)
	$basvuru = get_page_by_path( 'basvuru' );
	if ( ! $basvuru ) {
		$basvuru_id = wp_insert_post( array(
			'post_title'   => 'Başvuru Formu',
			'post_name'    => 'basvuru',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_content' => '',
		) );
	} else {
		$basvuru_id = $basvuru->ID;
	}

	// 2. Ana menü: bölüm bağlantıları ve başvuru sayfası
	$menu_adi = 'Ana Menü';
	$menu     = wp_get_nav_menu_object( $menu_adi );
	if ( ! $menu ) {
		$menu_id = wp_create_nav_menu( $menu_adi );
		if ( ! is_wp_error( $menu_id ) ) {
			$kalemler = array(
				array( 'title' => 'Eğitimler',  'url' => home_url( '/#egitimler' ) ),
				array( 'title' => 'Kurumsal',   'url' => home_url( '/#kurumsal' ) ),
				array( 'title' => 'Programlar', 'url' => home_url( '/#programlar' ) ),
				array( 'title' => 'İletişim',   'url' => home_url( '/#iletisim' ) ),
			);
			foreach ( $kalemler as $sira => $kalem ) {
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'     => $kalem['title'],
					'menu-item-url'       => $kalem['url'],
					'menu-item-status'    => 'publish',
					'menu-item-type'      => 'custom',
					'menu-item-position'  => $sira + 1,
				) );
			}
			if ( $basvuru_id && ! is_wp_error( $basvuru_id ) ) {
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'     => 'Başvuru Yapın',
					'menu-item-object-id' => $basvuru_id,
					'menu-item-object'    => 'page',
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
					'menu-item-position'  => 5,
				) );
			}
		}
		$menu = wp_get_nav_menu_object( $menu_adi );
	}
	if ( $menu ) {
		$konumlar = get_theme_mod( 'nav_menu_locations', array() );
		$konumlar['primary'] = $menu->term_id;
		set_theme_mod( 'nav_menu_locations', $konumlar );
	}

	// 3. Ana sayfa: sayfa olarak ayarla (front-page.php kullanılır)
	$ana = get_page_by_path( 'ana-sayfa' );
	if ( ! $ana ) {
		$ana_id = wp_insert_post( array(
			'post_title'  => 'Ana Sayfa',
			'post_name'   => 'ana-sayfa',
			'post_status' => 'publish',
			'post_type'   => 'page',
		) );
	} else {
		$ana_id = $ana->ID;
	}
	if ( $ana_id && ! is_wp_error( $ana_id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ana_id );
	}

	// 4. Kalıcı bağlantılar
	flush_rewrite_rules();

	update_option( 'ragip_setup_done', 1 );
}
